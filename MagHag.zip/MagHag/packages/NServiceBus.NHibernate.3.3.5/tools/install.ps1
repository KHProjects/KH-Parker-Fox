param($installPath, $toolsPath, $package, $project)

Add-BindingRedirect