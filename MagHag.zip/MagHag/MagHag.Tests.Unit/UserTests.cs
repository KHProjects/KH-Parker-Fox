﻿using MagHag.Core.Entities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagHag.Tests.Unit
{
    [TestFixture]
    public class UserTests
    {
        [Test]
        public void ApplyEvents()
        {
            User user = new User();
        }

    }
}
