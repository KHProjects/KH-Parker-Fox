﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ParkerFox.Site.ViewModels
{
    public class ApplyForLoanViewModel
    {
        public decimal Amount { get; set; }
        public int PayDay { get; set; }
    }
}